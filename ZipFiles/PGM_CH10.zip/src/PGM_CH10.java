// ****************************************************************************
// Author: Alex Hennessy
// Section: CSCI 136-01
// File: TestCow
// Date: 10/23/2015
// Purpose: PGM_CH10: Dummy Class.
// Code Integrity:
// I certify that this program is my own source code.
// I received help from: Austin Mahler
// in the design, construction, and debugging of this source code.
// ****************************************************************************

public class PGM_CH10 
{
	public static void main (String[] args)
	{
		
	}
}
